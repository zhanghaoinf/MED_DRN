#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import string
import os
import scipy.io as sio
import scipy
from subroutine import createFolder
# Make sure that caffe is on the python path:
caffe_root = '/home/hzhang57/DRN/caffe_b59/' # this file is expected to be in {caffe_root}/example
import sys
sys.path.insert(0,caffe_root + 'python')
import caffe

# Set the right path to your model definition file, pretrained model weights
# and the image you would like to classify
DATA_ROOT = '/home/hzhang57/DRN/DRN_Model/'
tv_root   = '/home/hzhang57/Data/MED'
MODEL_FILE = os.path.join( DATA_ROOT , 'ResNet_50_deploy.prototxt' )
PRETRAINED = os.path.join( DATA_ROOT , 'ResNet_50.caffemodel' )
caffe.set_device(1)
caffe.set_mode_gpu()
#caffe.set_mode_cpu()
net = caffe.Net(MODEL_FILE, PRETRAINED, caffe.TEST)

# input preprocessing: 'data' is the name of the input blob == net.inputs[0]
transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_mean('data',np.load(DATA_ROOT + 'ResNet_mean.npy').mean(1).mean(1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))
net.blobs['data'].reshape(1,3,224,224)
############# DATA Set ##################### This part is defined by user #################33
Fmt = 'jpg'
FeatFmt = 'txt'
DataSet = 'E021-E040_100Ex'
InputFolder  = os.path.join(tv_root, 'VIDEO_ORIGINAL_KF',DataSet)
FileList     = os.path.join(tv_root,'STRUCTURE' ,DataSet + '.txt')
OutputFolder_5= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L5/')
OutputFolder_4= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4/')
OutputFolder_3= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3/')
OutputFolder_2= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2/')
OutputFolder_pool5 = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_pool5/')
OutputFolder_fc    = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_fc/')
OutputFolder_prob  = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_prob/')
createFolder(OutputFolder_5)
createFolder(OutputFolder_4)
createFolder(OutputFolder_3)
createFolder(OutputFolder_2)
createFolder(OutputFolder_pool5)
createFolder(OutputFolder_fc)
createFolder(OutputFolder_prob)
#############################################################################################

ArgvLen = len(sys.argv)
if ArgvLen !=3:
	print ("-"*30)
	print ("Number of argv not correct\n please specify start and end number")
	print ("-"*30)
	exit(0)
StartLine = string.atoi(sys.argv[1])
EndLine   = string.atoi(sys.argv[2])
CntRange  = range(StartLine-1, EndLine)
Fid = open(FileList)
VidLists = Fid.readlines()
VidNum   = len(VidLists)
Dispp = '|' + str(VidNum) + '|' +str(EndLine) + "----" + str(StartLine-1) + ":"
for Cnt in CntRange:
	print Dispp + str(Cnt)
	Vid = VidLists[Cnt].strip()
	VideoFolder = os.path.join(InputFolder, Vid)

	#print VideoFolder#####################################
	OutFeatFolder_5 = os.path.join(OutputFolder_5, Vid)
	OutFeatFolder_4 = os.path.join(OutputFolder_4, Vid)
	OutFeatFolder_3 = os.path.join(OutputFolder_3, Vid)
	OutFeatFolder_2 = os.path.join(OutputFolder_2, Vid)
	OutFeatFolder_pool5 = os.path.join(OutputFolder_pool5, Vid)
	OutFeatFolder_fc    = os.path.join(OutputFolder_fc, Vid)
	OutFeatFolder_prob  = os.path.join(OutputFolder_prob, Vid)
	createFolder(OutFeatFolder_5)
	createFolder(OutFeatFolder_4)
	createFolder(OutFeatFolder_3)
	createFolder(OutFeatFolder_2)
	createFolder(OutFeatFolder_pool5)
	createFolder(OutFeatFolder_fc)
	createFolder(OutFeatFolder_prob)
	########################################################
	Images = os.listdir(VideoFolder)
	##################
	for SingleImage in Images:
		ImgPath = os.path.join(VideoFolder, SingleImage)
		# savePath
		imgFeatPath_5 = os.path.join(OutFeatFolder_5, SingleImage.replace('.'+Fmt, ''))
		imgFeatPath_4 = os.path.join(OutFeatFolder_4, SingleImage.replace('.'+Fmt, ''))
		imgFeatPath_3 = os.path.join(OutFeatFolder_3, SingleImage.replace('.'+Fmt, ''))
		imgFeatPath_2 = os.path.join(OutFeatFolder_2, SingleImage.replace('.'+Fmt, ''))
		imgFeatPath_pool5 = os.path.join(OutFeatFolder_pool5, SingleImage.replace('.'+Fmt, ''))
		imgFeatPath_fc = os.path.join(OutFeatFolder_fc, SingleImage.replace('.'+Fmt, ''))
		imgFeatPath_prob = os.path.join(OutFeatFolder_prob, SingleImage.replace('.'+Fmt, ''))
		# extract Feature
		InputImage = caffe.io.load_image(ImgPath)
		net.blobs['data'].data[...] = transformer.preprocess('data',InputImage)
		out = net.forward()
		res5c =  (net.blobs['res5c'].data[0])
		res5b =  (net.blobs['res5b'].data[0])
		res5a =  (net.blobs['res5a'].data[0])
		sio.savemat(imgFeatPath_5, {'res5a':res5a, 'res5b':res5b, 'res5c':res5c})
		res4f =  (net.blobs['res4f'].data[0])
		res4e =  (net.blobs['res4e'].data[0])
		res4d =  (net.blobs['res4d'].data[0])
		res4c =  (net.blobs['res4c'].data[0])
		res4b =  (net.blobs['res4b'].data[0])
		res4a =  (net.blobs['res4a'].data[0])
		sio.savemat(imgFeatPath_4, {'res4a':res4a, 'res4b':res4b, 'res4c':res4c, 'res4d':res4d, 'res4e':res4e, 'res4f':res4f})
		res3d =  (net.blobs['res3d'].data[0])
		res3c =  (net.blobs['res3c'].data[0])
		res3b =  (net.blobs['res3b'].data[0])
		res3a =  (net.blobs['res3a'].data[0])
		sio.savemat(imgFeatPath_3, {'res3a':res3a, 'res3b':res3b, 'res3c':res3c, 'res3d':res3d})
		res2c =  (net.blobs['res2c'].data[0])
		res2b =  (net.blobs['res2b'].data[0])
		res2a =  (net.blobs['res2a'].data[0])
		sio.savemat(imgFeatPath_2, {'res2a':res2a, 'res2b':res2b, 'res2c':res2c})
		pool5 =  (net.blobs['pool5'].data[0])
		sio.savemat(imgFeatPath_pool5, {'pool5':pool5})
		fc    =  (net.blobs['fc1000'].data[0])
		sio.savemat(imgFeatPath_fc, {'fc':fc})
		prob  =  (net.blobs['prob'].data[0])
		sio.savemat(imgFeatPath_prob, {'prob':prob})
	# 7zip
	
print 'Finish'



