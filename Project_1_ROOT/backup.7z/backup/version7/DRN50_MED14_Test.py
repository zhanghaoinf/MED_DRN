#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import string
import os
import scipy.io as sio
import scipy
from subroutine import createFolder
# Make sure that caffe is on the python path:
caffe_root = '/home/hzhang57/DRN/caffe_b59/' # this file is expected to be in {caffe_root}/example
import sys
sys.path.insert(0,caffe_root + 'python')
import caffe

# Set the right path to your model definition file, pretrained model weights
# and the image you would like to classify
DATA_ROOT = '/home/hzhang57/DRN/DRN_Model/'
tv_root   = '/home/hzhang57/Data/MED'
MODEL_FILE = os.path.join( DATA_ROOT , 'ResNet_50_deploy.prototxt' )
PRETRAINED = os.path.join( DATA_ROOT , 'ResNet_50.caffemodel' )
caffe.set_device(1)
caffe.set_mode_gpu()
#caffe.set_mode_cpu()
net = caffe.Net(MODEL_FILE, PRETRAINED, caffe.TEST)

# input preprocessing: 'data' is the name of the input blob == net.inputs[0]
transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_mean('data',np.load(DATA_ROOT + 'ResNet_mean.npy').mean(1).mean(1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))
net.blobs['data'].reshape(1,3,224,224)
############# DATA Set ##################### This part is defined by user #################33
Fmt = 'jpg'
FeatFmt = 'txt'
DataSet = 'MED14_Test'
InputFolder  = os.path.join(tv_root, 'VIDEO_ORIGINAL_KF',DataSet)
FileList     = os.path.join(tv_root,'STRUCTURE' ,DataSet + '.txt')
OutputFolder_5a= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L5a')
OutputFolder_5b= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L5b')
OutputFolder_5c= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L5c')
OutputFolder_4a= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4a')
OutputFolder_4b= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4b')
OutputFolder_4c= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4c')
OutputFolder_4d= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4d')
OutputFolder_4e= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4e')
OutputFolder_4f= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4f')
OutputFolder_3a= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3a')
OutputFolder_3b= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3b')
OutputFolder_3c= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3c')
OutputFolder_3d= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3d')
OutputFolder_2a= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2a')
OutputFolder_2b= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2b')
OutputFolder_2c= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2c')
OutputFolder_pool5 = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_pool5/')
OutputFolder_fc    = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_fc/')
OutputFolder_prob  = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_prob/')
createFolder(OutputFolder_5a)
createFolder(OutputFolder_5b)
createFolder(OutputFolder_5c)
createFolder(OutputFolder_4a)
createFolder(OutputFolder_4b)
createFolder(OutputFolder_4c)
createFolder(OutputFolder_4d)
createFolder(OutputFolder_4e)
createFolder(OutputFolder_4f)
createFolder(OutputFolder_3a)
createFolder(OutputFolder_3b)
createFolder(OutputFolder_3c)
createFolder(OutputFolder_3d)
createFolder(OutputFolder_2a)
createFolder(OutputFolder_2b)
createFolder(OutputFolder_2c)
createFolder(OutputFolder_pool5)
createFolder(OutputFolder_fc)
createFolder(OutputFolder_prob)
#############################################################################################

ArgvLen = len(sys.argv)
if ArgvLen !=3:
	print ("-"*30)
	print ("Number of argv not correct\n please specify start and end number")
	print ("-"*30)
	exit(0)
StartLine = string.atoi(sys.argv[1])
EndLine   = string.atoi(sys.argv[2])
CntRange  = range(StartLine-1, EndLine)
Fid = open(FileList)
VidLists = Fid.readlines()
VidNum   = len(VidLists)
Dispp = '|' + str(VidNum) + '|' +str(EndLine) + "----" + str(StartLine-1) + ":"
for Cnt in CntRange:
	print Dispp + str(Cnt)
	Vid = VidLists[Cnt].strip()
	VideoFolder = os.path.join(InputFolder, Vid)

	#print VideoFolder#####################################
	OutFeat_5a = os.path.join(OutputFolder_5a, Vid+'.mat')
	OutFeat_5b = os.path.join(OutputFolder_5b, Vid+'.mat')
	OutFeat_5c = os.path.join(OutputFolder_5c, Vid+'.mat')
	OutFeat_4a = os.path.join(OutputFolder_4a, Vid+'.mat')
	OutFeat_4b = os.path.join(OutputFolder_4b, Vid+'.mat')
	OutFeat_4c = os.path.join(OutputFolder_4c, Vid+'.mat')
	OutFeat_4d = os.path.join(OutputFolder_4d, Vid+'.mat')
	OutFeat_4e = os.path.join(OutputFolder_4e, Vid+'.mat')
	OutFeat_4f = os.path.join(OutputFolder_4f, Vid+'.mat')
	OutFeat_3a = os.path.join(OutputFolder_3a, Vid+'.mat')
	OutFeat_3b = os.path.join(OutputFolder_3b, Vid+'.mat')
	OutFeat_3c = os.path.join(OutputFolder_3c, Vid+'.mat')
	OutFeat_3d = os.path.join(OutputFolder_3d, Vid+'.mat')
	OutFeat_2a = os.path.join(OutputFolder_2a, Vid+'.mat')
	OutFeat_2b = os.path.join(OutputFolder_2b, Vid+'.mat')
	OutFeat_2c = os.path.join(OutputFolder_2c, Vid+'.mat')
	OutFeat_pool5 = os.path.join(OutputFolder_pool5, Vid+'.mat')
	OutFeat_fc    = os.path.join(OutputFolder_fc, Vid+'.mat')
	OutFeat_prob  = os.path.join(OutputFolder_prob, Vid+'.mat')
	########################################################
	Images = os.listdir(VideoFolder)
	# Dict Version
	featDict5a = {}
	featDict5b = {}
	featDict5c = {}
	featDict4a = {}
	featDict4b = {}
	featDict4c = {}
	featDict4d = {}
	featDict4e = {}
	featDict4f = {}
	featDict3a = {}
	featDict3b = {}
	featDict3c = {}
	featDict3d = {}
	featDict2a = {}
	featDict2b = {}
	featDict2c = {}
	featDictpool5 = {}
	featDictfc = {}
	featDictprob = {}
	##################
	if not os.path.exists(OutFeat_prob):
		for SingleImage in Images:
			ImgPath = os.path.join(VideoFolder, SingleImage)
			InputImage = caffe.io.load_image(ImgPath)
			net.blobs['data'].data[...] = transformer.preprocess('data',InputImage)
			out = net.forward()
			res5c = (net.blobs['res5c'].data[0])
			res5b =  (net.blobs['res5b'].data[0])
			res5a =  (net.blobs['res5a'].data[0])
			res4f =  (net.blobs['res4f'].data[0])
			res4e =  (net.blobs['res4e'].data[0])
			res4d =  (net.blobs['res4d'].data[0])
			res4c =  (net.blobs['res4c'].data[0])
			res4b =  (net.blobs['res4b'].data[0])
			res4a =  (net.blobs['res4a'].data[0])
			res3d =  (net.blobs['res3d'].data[0])
			res3c =  (net.blobs['res3c'].data[0])
			res3b =  (net.blobs['res3b'].data[0])
			res3a =  (net.blobs['res3a'].data[0])
			res2c =  (net.blobs['res2c'].data[0])
			res2b =  (net.blobs['res2b'].data[0])
			res2a =  (net.blobs['res2a'].data[0])
			pool5 =  (net.blobs['pool5'].data[0])
			fc    =  (net.blobs['fc1000'].data[0])
			prob  = (net.blobs['prob'].data[0])
			featDict5a[SingleImage.replace('.'+Fmt, '')] = res5a
			featDict5b[SingleImage.replace('.'+Fmt, '')] = res5b
			featDict5c[SingleImage.replace('.'+Fmt, '')] = res5c
			featDict4a[SingleImage.replace('.'+Fmt, '')] = res4a
			featDict4b[SingleImage.replace('.'+Fmt, '')] = res4b
			featDict4c[SingleImage.replace('.'+Fmt, '')] = res4c
			featDict4d[SingleImage.replace('.'+Fmt, '')] = res4d
			featDict4e[SingleImage.replace('.'+Fmt, '')] = res4e
			featDict4f[SingleImage.replace('.'+Fmt, '')] = res4f
			featDict3a[SingleImage.replace('.'+Fmt, '')] = res3a
			featDict3b[SingleImage.replace('.'+Fmt, '')] = res3b
			featDict3c[SingleImage.replace('.'+Fmt, '')] = res3c
			featDict3d[SingleImage.replace('.'+Fmt, '')] = res3d
			featDict2a[SingleImage.replace('.'+Fmt, '')] = res2a
			featDict2b[SingleImage.replace('.'+Fmt, '')] = res2b
			featDict2c[SingleImage.replace('.'+Fmt, '')] = res2c
			featDictpool5[SingleImage.replace('.'+Fmt, '')] = pool5
			featDictfc[SingleImage.replace('.'+Fmt, '')] = fc
			featDictprob[SingleImage.replace('.'+Fmt, '')] = prob
		sio.savemat(OutFeat_5a, {'feat5a':featDict5a})
		OutTar_5a = OutFeat_5a.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_5a + ' ' + OutFeat_5a
		cmd2 = 'rm ' + OutFeat_5a
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_5b, {'feat5b':featDict5b})
		OutTar_5b = OutFeat_5b.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_5b + ' ' + OutFeat_5b
		cmd2 = 'rm ' + OutFeat_5b
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_5c, {'feat5c':featDict5c})
		OutTar_5c = OutFeat_5c.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_5c + ' ' + OutFeat_5c
		cmd2 = 'rm ' + OutFeat_5c
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_4a, {'feat4a':featDict4a})
		OutTar_4a = OutFeat_4a.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4a + ' ' + OutFeat_4a
		cmd2 = 'rm ' + OutFeat_4a
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_4b, {'feat4b':featDict4b})
		OutTar_4b = OutFeat_4b.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4b + ' ' + OutFeat_4b
		cmd2 = 'rm ' + OutFeat_4b
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_4c, {'feat4c':featDict4c})
		OutTar_4c = OutFeat_4c.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4c + ' ' + OutFeat_4c
		cmd2 = 'rm ' + OutFeat_4c
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_4d, {'feat4d':featDict4d})
		OutTar_4d = OutFeat_4d.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4d + ' ' + OutFeat_4d
		cmd2 = 'rm ' + OutFeat_4d
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_4e, {'feat4e':featDict4e})
		OutTar_4e = OutFeat_4e.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4e + ' ' + OutFeat_4e
		cmd2 = 'rm ' + OutFeat_4e
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_4f, {'feat4f':featDict4f})
		OutTar_4f = OutFeat_4f.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4f + ' ' + OutFeat_4f
		cmd2 = 'rm ' + OutFeat_4f
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_3a, {'feat3a':featDict3a})
		OutTar_3a = OutFeat_3a.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3a + ' ' + OutFeat_3a
		cmd2 = 'rm ' + OutFeat_3a
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_3b, {'feat3b':featDict3b})
		OutTar_3b = OutFeat_3b.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3b + ' ' + OutFeat_3b
		cmd2 = 'rm ' + OutFeat_3b
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_3c, {'feat3c':featDict3c})
		OutTar_3c = OutFeat_3c.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3c + ' ' + OutFeat_3c
		cmd2 = 'rm ' + OutFeat_3c
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_3d, {'feat3d':featDict3d})
		OutTar_3d = OutFeat_3d.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3d + ' ' + OutFeat_3d
		cmd2 = 'rm ' + OutFeat_3d
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_2a, {'feat2a':featDict2a})
		OutTar_2a = OutFeat_2a.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_2a + ' ' + OutFeat_2a
		cmd2 = 'rm ' + OutFeat_2a
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_2b, {'feat2b':featDict2b})
		OutTar_2b = OutFeat_2b.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_2b + ' ' + OutFeat_2b
		cmd2 = 'rm ' + OutFeat_2b
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_2c, {'feat2c':featDict2c})
		OutTar_2c = OutFeat_2c.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_2c + ' ' + OutFeat_2c
		cmd2 = 'rm ' + OutFeat_2c
		os.system(cmd1)
		#os.system(cmd2)
		#
		sio.savemat(OutFeat_pool5, {'pool5':featDictpool5})
		sio.savemat(OutFeat_fc, {'fc':featDictfc})
		sio.savemat(OutFeat_prob, {'prob':featDictprob})
print 'Finish'



