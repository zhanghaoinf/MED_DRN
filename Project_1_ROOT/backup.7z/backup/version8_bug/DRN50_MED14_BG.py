#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import string
import os
import scipy.io as sio
import scipy
from subroutine import createFolder
# Make sure that caffe is on the python path:
caffe_root = '/home/hzhang57/DRN/caffe_b59/' # this file is expected to be in {caffe_root}/example
import sys
sys.path.insert(0,caffe_root + 'python')
import caffe

# Set the right path to your model definition file, pretrained model weights
# and the image you would like to classify
DATA_ROOT = '/home/hzhang57/DRN/DRN_Model/'
tv_root   = '/home/hzhang57/Data/MED'
MODEL_FILE = os.path.join( DATA_ROOT , 'ResNet_50_deploy.prototxt' )
PRETRAINED = os.path.join( DATA_ROOT , 'ResNet_50.caffemodel' )
caffe.set_device(1)
caffe.set_mode_gpu()
#caffe.set_mode_cpu()
net = caffe.Net(MODEL_FILE, PRETRAINED, caffe.TEST)

# input preprocessing: 'data' is the name of the input blob == net.inputs[0]
transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_mean('data',np.load(DATA_ROOT + 'ResNet_mean.npy').mean(1).mean(1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))
net.blobs['data'].reshape(1,3,224,224)
############# DATA Set ##################### This part is defined by user #################33
Fmt = 'jpg'
FeatFmt = 'txt'
DataSet = 'Event_BG'
InputFolder  = os.path.join(tv_root, 'VIDEO_ORIGINAL_KF',DataSet)
FileList     = os.path.join(tv_root,'STRUCTURE' ,DataSet + '.txt')
OutputFolder_5= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L5/')
OutputFolder_4= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L4/')
OutputFolder_3A= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3A/')
OutputFolder_3B= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3B/')
OutputFolder_3C= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3C/')
OutputFolder_3D= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L3D/')
OutputFolder_2A= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2A/')
OutputFolder_2B= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2B/')
OutputFolder_2C= os.path.join( tv_root,'Features/' ,DataSet ,'DRN50_L2C/')
OutputFolder_pool5 = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_pool5/')
OutputFolder_fc    = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_fc/')
OutputFolder_prob  = os.path.join( tv_root,'Features/' ,DataSet,'DRN50_prob/')
createFolder(OutputFolder_5)
createFolder(OutputFolder_4)
createFolder(OutputFolder_3A)
createFolder(OutputFolder_3B)
createFolder(OutputFolder_3C)
createFolder(OutputFolder_3D)
createFolder(OutputFolder_2A)
createFolder(OutputFolder_2B)
createFolder(OutputFolder_2C)
createFolder(OutputFolder_pool5)
createFolder(OutputFolder_fc)
createFolder(OutputFolder_prob)
#############################################################################################

ArgvLen = len(sys.argv)
if ArgvLen !=3:
	print ("-"*30)
	print ("Number of argv not correct\n please specify start and end number")
	print ("-"*30)
	exit(0)
StartLine = string.atoi(sys.argv[1])
EndLine   = string.atoi(sys.argv[2])
CntRange  = range(StartLine-1, EndLine)
Fid = open(FileList)
VidLists = Fid.readlines()
VidNum   = len(VidLists)
Dispp = '|' + str(VidNum) + '|' +str(EndLine) + "----" + str(StartLine-1) + ":"
for Cnt in CntRange:
	print Dispp + str(Cnt)
	Vid = VidLists[Cnt].strip()
	VideoFolder = os.path.join(InputFolder, Vid)

	#print VideoFolder#####################################
	OutFeat_5 = os.path.join(OutputFolder_5, Vid+'.mat')
	OutFeat_4 = os.path.join(OutputFolder_4, Vid+'.mat')
	OutFeat_3A = os.path.join(OutputFolder_3A, Vid+'.mat')
	OutFeat_3B = os.path.join(OutputFolder_3B, Vid+'.mat')
	OutFeat_3C = os.path.join(OutputFolder_3C, Vid+'.mat')
	OutFeat_3D = os.path.join(OutputFolder_3D, Vid+'.mat')
	OutFeat_2A = os.path.join(OutputFolder_2A, Vid+'.mat')
	OutFeat_2B = os.path.join(OutputFolder_2B, Vid+'.mat')
	OutFeat_2C = os.path.join(OutputFolder_2C, Vid+'.mat')
	OutFeat_pool5 = os.path.join(OutputFolder_pool5, Vid+'.mat')
	OutFeat_fc    = os.path.join(OutputFolder_fc, Vid+'.mat')
	OutFeat_prob  = os.path.join(OutputFolder_prob, Vid+'.mat')
	########################################################
	Images = os.listdir(VideoFolder)
	# Dict Version
	featDict5 = {}
	featDict4 = {}
	featDict3A = {}
	featDict3B = {}
	featDict3C = {}
	featDict3D = {}
	featDict2A = {}
	featDict2B = {}
	featDict2C = {}
	featDictpool5 = {}
	featDictfc = {}
	featDictprob = {}
	maxFrame = min(500, len(Images))
	##################
	if not os.path.exists(OutFeat_prob):
		for cnt in range(1, maxFrame+1):
			SingleImage = Vid + '_' + str(cnt) + '_OKF.jpg'
			ImgPath = os.path.join(VideoFolder, SingleImage)
			InputImage = caffe.io.load_image(ImgPath)
			net.blobs['data'].data[...] = transformer.preprocess('data',InputImage)
			feat5 ={}
			feat4 ={}
			out = net.forward()
			feat5['res5c'] = (net.blobs['res5c'].data[0])
			feat5['res5b'] =  (net.blobs['res5b'].data[0])
			feat5['res5a'] =  (net.blobs['res5a'].data[0])
			feat4['res4f'] =  (net.blobs['res4f'].data[0])
			feat4['res4e'] =  (net.blobs['res4e'].data[0])
			feat4['res4d'] =  (net.blobs['res4d'].data[0])
			feat4['res4c'] =  (net.blobs['res4c'].data[0])
			feat4['res4b'] =  (net.blobs['res4b'].data[0])
			feat4['res4a'] =  (net.blobs['res4a'].data[0])
			res3d =  (net.blobs['res3d'].data[0])
			res3c =  (net.blobs['res3c'].data[0])
			res3b =  (net.blobs['res3b'].data[0])
			res3a =  (net.blobs['res3a'].data[0])
			res2c =  (net.blobs['res2c'].data[0])
			res2b =  (net.blobs['res2b'].data[0])
			res2a =  (net.blobs['res2a'].data[0])
			pool5 =  (net.blobs['pool5'].data[0])
			fc    =  (net.blobs['fc1000'].data[0])
			prob  = (net.blobs['prob'].data[0])
			featDict5[SingleImage.replace('.'+Fmt, '')] = feat5
			featDict4[SingleImage.replace('.'+Fmt, '')] = feat4
			featDict3A[SingleImage.replace('.'+Fmt, '')] = res3a
			featDict3B[SingleImage.replace('.'+Fmt, '')] = res3b
			featDict3C[SingleImage.replace('.'+Fmt, '')] = res3c
			featDict3D[SingleImage.replace('.'+Fmt, '')] = res3d
			featDict2A[SingleImage.replace('.'+Fmt, '')] = res2a
			featDict2B[SingleImage.replace('.'+Fmt, '')] = res2b
			featDict2C[SingleImage.replace('.'+Fmt, '')] = res2c
			featDictpool5[SingleImage.replace('.'+Fmt, '')] = pool5
			featDictfc[SingleImage.replace('.'+Fmt, '')] = fc
			featDictprob[SingleImage.replace('.'+Fmt, '')] = prob
			print prob[1]
		sio.savemat(OutFeat_5, {'feat5':featDict5})
		OutTar_5 = OutFeat_5.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_5 + ' ' + OutFeat_5
		cmd2 = 'rm ' + OutFeat_5
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_4, {'feat4':featDict4})
		OutTar_4 = OutFeat_4.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_4 + ' ' + OutFeat_4
		cmd2 = 'rm ' + OutFeat_4
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_3A, {'feat3A':featDict3A})
		OutTar_3A = OutFeat_3A.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3A + ' ' + OutFeat_3A
		cmd2 = 'rm ' + OutFeat_3A
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_3B, {'feat3B':featDict3B})
		OutTar_3B = OutFeat_3B.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3B + ' ' + OutFeat_3B
		cmd2 = 'rm ' + OutFeat_3B
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_3C, {'feat3C':featDict3C})
		OutTar_3C = OutFeat_3C.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3C + ' ' + OutFeat_3C
		cmd2 = 'rm ' + OutFeat_3C
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_3D, {'feat3D':featDict3D})
		OutTar_3D = OutFeat_3D.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_3D + ' ' + OutFeat_3D
		cmd2 = 'rm ' + OutFeat_3D
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_2A, {'feat2A':featDict2A})
		OutTar_2A = OutFeat_2A.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_2A + ' ' + OutFeat_2A
		cmd2 = 'rm ' + OutFeat_2A
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_2B, {'feat2B':featDict2B})
		OutTar_2B = OutFeat_2B.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_2B + ' ' + OutFeat_2B
		cmd2 = 'rm ' + OutFeat_2B
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_2C, {'feat2C':featDict2C})
		OutTar_2C = OutFeat_2C.replace('.mat','.7z')
		cmd1 = '7za a -t7z -m0=LZMA2 -mmt=10 ' + OutTar_2C + ' ' + OutFeat_2C
		cmd2 = 'rm ' + OutFeat_2C
		os.system(cmd1)
		os.system(cmd2)
		#
		sio.savemat(OutFeat_pool5, {'pool5':featDictpool5})
		sio.savemat(OutFeat_fc, {'fc':featDictfc})
		sio.savemat(OutFeat_prob, {'prob':featDictprob})
print 'Finish'



